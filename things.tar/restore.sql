--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "471";
--
-- Name: 471; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "471" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "471" OWNER TO postgres;

\connect "471"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: diet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.diet (
    diet_id integer NOT NULL,
    diet_rou_id integer NOT NULL,
    diet_username character varying(100) NOT NULL,
    diet_difficulty character varying(100),
    diet_length interval day,
    diet_goal character varying(100),
    diet_name character varying(100),
    CONSTRAINT diet_diet_difficulty_check CHECK ((((diet_difficulty)::text = 'Beginner'::text) OR ((diet_difficulty)::text = 'Intermediate'::text) OR ((diet_difficulty)::text = 'Advanced'::text))),
    CONSTRAINT diet_diet_goal_check CHECK ((((diet_goal)::text = 'Lose Weight'::text) OR ((diet_goal)::text = 'Maintain Weight'::text) OR ((diet_goal)::text = 'Gain Weight'::text)))
);


ALTER TABLE public.diet OWNER TO postgres;

--
-- Name: diet_diet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.diet_diet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diet_diet_id_seq OWNER TO postgres;

--
-- Name: diet_diet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.diet_diet_id_seq OWNED BY public.diet.diet_id;


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment (
    equip_name character varying(100) NOT NULL,
    equip_picture character varying(100)
);


ALTER TABLE public.equipment OWNER TO postgres;

--
-- Name: exer_set; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exer_set (
    exer_set_id integer NOT NULL,
    exer_set_num_reps integer,
    exer_set_time interval second,
    exer_set_distance double precision,
    exer_set_weight double precision,
    exer_set_type character varying(100),
    exer_set_comment character varying(255),
    exer_username character varying(100) NOT NULL,
    CONSTRAINT exer_set_exer_set_type_check CHECK ((((exer_set_type)::text = 'Strength'::text) OR ((exer_set_type)::text = 'Cardio'::text) OR ((exer_set_type)::text = 'Other'::text)))
);


ALTER TABLE public.exer_set OWNER TO postgres;

--
-- Name: exercise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise (
    exercise_id integer NOT NULL,
    exercise_name character varying(100) NOT NULL,
    exercise_type character varying(100) NOT NULL,
    exercise_num_sets integer,
    exercise_workout_id integer,
    exercise_comment character varying(255),
    exercise_creator_username character varying(100) NOT NULL,
    exercise_user_username character varying(100),
    CONSTRAINT exercise_exercise_type_check CHECK ((((exercise_type)::text = 'Strength'::text) OR ((exercise_type)::text = 'Cardio'::text) OR ((exercise_type)::text = 'Other'::text)))
);


ALTER TABLE public.exercise OWNER TO postgres;

--
-- Name: exercise_exercise_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exercise_exercise_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercise_exercise_id_seq OWNER TO postgres;

--
-- Name: exercise_exercise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exercise_exercise_id_seq OWNED BY public.exercise.exercise_id;


--
-- Name: exercise_muscle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise_muscle (
    exercise_muscle_id integer NOT NULL,
    exercise_muscle_muscle character varying(100) NOT NULL
);


ALTER TABLE public.exercise_muscle OWNER TO postgres;

--
-- Name: personnel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personnel (
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    weight double precision,
    goal_weight double precision,
    training_goal character varying(100),
    height integer,
    age integer,
    CONSTRAINT personnel_age_check CHECK ((age > 0)),
    CONSTRAINT personnel_goal_weight_check CHECK ((goal_weight > (0)::double precision)),
    CONSTRAINT personnel_height_check CHECK ((height > 0)),
    CONSTRAINT personnel_training_goal_check CHECK ((((training_goal)::text = 'Lose Weight'::text) OR ((training_goal)::text = 'Gain Weight'::text) OR ((training_goal)::text = 'Maintain Weight'::text))),
    CONSTRAINT personnel_weight_check CHECK ((weight > (0)::double precision))
);


ALTER TABLE public.personnel OWNER TO postgres;

--
-- Name: rou; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rou (
    rou_id integer NOT NULL,
    rou_difficulty character varying(50),
    rou_name character varying(100) NOT NULL,
    rou_goal character varying(100),
    rou_length interval hour to minute,
    rou_split interval day,
    CONSTRAINT rou_rou_difficulty_check CHECK ((((rou_difficulty)::text = 'Beginner'::text) OR ((rou_difficulty)::text = 'Intermediate'::text) OR ((rou_difficulty)::text = 'Advanced'::text))),
    CONSTRAINT rou_rou_goal_check CHECK ((((rou_goal)::text = 'Gain'::text) OR ((rou_goal)::text = 'Lose'::text) OR ((rou_goal)::text = 'Maintain'::text)))
);


ALTER TABLE public.rou OWNER TO postgres;

--
-- Name: rou_rou_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rou_rou_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rou_rou_id_seq OWNER TO postgres;

--
-- Name: rou_rou_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rou_rou_id_seq OWNED BY public.rou.rou_id;


--
-- Name: use; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.use (
    use_exer_id integer NOT NULL,
    use_equip_name character varying(100) NOT NULL
);


ALTER TABLE public.use OWNER TO postgres;

--
-- Name: workout; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workout (
    workout_id integer NOT NULL,
    workout_date date NOT NULL,
    workout_difficulty character varying(100),
    workout_type character varying(100),
    workout_num_ex integer,
    workout_length interval hour to minute,
    workout_rou_id integer NOT NULL,
    workout_comment character varying(255),
    workout_username character varying(100) NOT NULL,
    CONSTRAINT workout_workout_difficulty_check CHECK ((((workout_difficulty)::text = 'Begginer'::text) OR ((workout_difficulty)::text = 'Intermediate'::text) OR ((workout_difficulty)::text = 'Advanced'::text))),
    CONSTRAINT workout_workout_num_ex_check CHECK ((workout_num_ex > 0)),
    CONSTRAINT workout_workout_type_check CHECK ((((workout_type)::text = 'Strength'::text) OR ((workout_type)::text = 'Cardio'::text) OR ((workout_type)::text = 'Other'::text)))
);


ALTER TABLE public.workout OWNER TO postgres;

--
-- Name: workout_muscle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workout_muscle (
    workout_wid integer NOT NULL,
    workout_muscle_muscle character varying(100)
);


ALTER TABLE public.workout_muscle OWNER TO postgres;

--
-- Name: workout_workout_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workout_workout_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workout_workout_id_seq OWNER TO postgres;

--
-- Name: workout_workout_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workout_workout_id_seq OWNED BY public.workout.workout_id;


--
-- Name: diet diet_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet ALTER COLUMN diet_id SET DEFAULT nextval('public.diet_diet_id_seq'::regclass);


--
-- Name: exercise exercise_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise ALTER COLUMN exercise_id SET DEFAULT nextval('public.exercise_exercise_id_seq'::regclass);


--
-- Name: rou rou_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rou ALTER COLUMN rou_id SET DEFAULT nextval('public.rou_rou_id_seq'::regclass);


--
-- Name: workout workout_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout ALTER COLUMN workout_id SET DEFAULT nextval('public.workout_workout_id_seq'::regclass);


--
-- Data for Name: diet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.diet (diet_id, diet_rou_id, diet_username, diet_difficulty, diet_length, diet_goal, diet_name) FROM stdin;
\.
COPY public.diet (diet_id, diet_rou_id, diet_username, diet_difficulty, diet_length, diet_goal, diet_name) FROM '$$PATH$$/2910.dat';

--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment (equip_name, equip_picture) FROM stdin;
\.
COPY public.equipment (equip_name, equip_picture) FROM '$$PATH$$/2916.dat';

--
-- Data for Name: exer_set; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exer_set (exer_set_id, exer_set_num_reps, exer_set_time, exer_set_distance, exer_set_weight, exer_set_type, exer_set_comment, exer_username) FROM stdin;
\.
COPY public.exer_set (exer_set_id, exer_set_num_reps, exer_set_time, exer_set_distance, exer_set_weight, exer_set_type, exer_set_comment, exer_username) FROM '$$PATH$$/2915.dat';

--
-- Data for Name: exercise; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercise (exercise_id, exercise_name, exercise_type, exercise_num_sets, exercise_workout_id, exercise_comment, exercise_creator_username, exercise_user_username) FROM stdin;
\.
COPY public.exercise (exercise_id, exercise_name, exercise_type, exercise_num_sets, exercise_workout_id, exercise_comment, exercise_creator_username, exercise_user_username) FROM '$$PATH$$/2913.dat';

--
-- Data for Name: exercise_muscle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercise_muscle (exercise_muscle_id, exercise_muscle_muscle) FROM stdin;
\.
COPY public.exercise_muscle (exercise_muscle_id, exercise_muscle_muscle) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: personnel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personnel (username, password, weight, goal_weight, training_goal, height, age) FROM stdin;
\.
COPY public.personnel (username, password, weight, goal_weight, training_goal, height, age) FROM '$$PATH$$/2904.dat';

--
-- Data for Name: rou; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rou (rou_id, rou_difficulty, rou_name, rou_goal, rou_length, rou_split) FROM stdin;
\.
COPY public.rou (rou_id, rou_difficulty, rou_name, rou_goal, rou_length, rou_split) FROM '$$PATH$$/2906.dat';

--
-- Data for Name: use; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.use (use_exer_id, use_equip_name) FROM stdin;
\.
COPY public.use (use_exer_id, use_equip_name) FROM '$$PATH$$/2917.dat';

--
-- Data for Name: workout; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workout (workout_id, workout_date, workout_difficulty, workout_type, workout_num_ex, workout_length, workout_rou_id, workout_comment, workout_username) FROM stdin;
\.
COPY public.workout (workout_id, workout_date, workout_difficulty, workout_type, workout_num_ex, workout_length, workout_rou_id, workout_comment, workout_username) FROM '$$PATH$$/2908.dat';

--
-- Data for Name: workout_muscle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workout_muscle (workout_wid, workout_muscle_muscle) FROM stdin;
\.
COPY public.workout_muscle (workout_wid, workout_muscle_muscle) FROM '$$PATH$$/2911.dat';

--
-- Name: diet_diet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.diet_diet_id_seq', 1, false);


--
-- Name: exercise_exercise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exercise_exercise_id_seq', 1, false);


--
-- Name: rou_rou_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rou_rou_id_seq', 1, false);


--
-- Name: workout_workout_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workout_workout_id_seq', 1, false);


--
-- Name: diet diet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet
    ADD CONSTRAINT diet_pkey PRIMARY KEY (diet_id, diet_rou_id, diet_username);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (equip_name);


--
-- Name: exer_set exer_set_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exer_set
    ADD CONSTRAINT exer_set_pkey PRIMARY KEY (exer_set_id, exer_username);


--
-- Name: exercise exercise_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_id_unique UNIQUE (exercise_id);


--
-- Name: exercise_muscle exercise_muscle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_muscle
    ADD CONSTRAINT exercise_muscle_pkey PRIMARY KEY (exercise_muscle_id);


--
-- Name: exercise exercise_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_pkey PRIMARY KEY (exercise_id, exercise_creator_username);


--
-- Name: personnel personnel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personnel
    ADD CONSTRAINT personnel_pkey PRIMARY KEY (username);


--
-- Name: rou rou_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rou
    ADD CONSTRAINT rou_pkey PRIMARY KEY (rou_id);


--
-- Name: use use_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.use
    ADD CONSTRAINT use_pkey PRIMARY KEY (use_exer_id, use_equip_name);


--
-- Name: workout_muscle workout_muscle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout_muscle
    ADD CONSTRAINT workout_muscle_pkey PRIMARY KEY (workout_wid);


--
-- Name: workout workout_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT workout_pkey PRIMARY KEY (workout_id, workout_username, workout_rou_id);


--
-- Name: workout workout_workout_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT workout_workout_id_key UNIQUE (workout_id);


--
-- Name: exer_set exer_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exer_set
    ADD CONSTRAINT exer_username_fkey FOREIGN KEY (exer_username) REFERENCES public.personnel(username) ON DELETE CASCADE;


--
-- Name: exercise exercise_creator_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_creator_username_fkey FOREIGN KEY (exercise_creator_username) REFERENCES public.personnel(username) ON DELETE CASCADE;


--
-- Name: exercise exercise_exercise_user_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_exercise_user_username_fkey FOREIGN KEY (exercise_user_username) REFERENCES public.personnel(username);


--
-- Name: exercise exercise_exercise_workout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_exercise_workout_id_fkey FOREIGN KEY (exercise_workout_id) REFERENCES public.workout(workout_id);


--
-- Name: exercise_muscle exercise_muscle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_muscle
    ADD CONSTRAINT exercise_muscle_id_fkey FOREIGN KEY (exercise_muscle_id) REFERENCES public.exercise(exercise_id) ON DELETE CASCADE;


--
-- Name: diet rou_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet
    ADD CONSTRAINT rou_id_fkey FOREIGN KEY (diet_rou_id) REFERENCES public.rou(rou_id) ON DELETE CASCADE;


--
-- Name: use use_equip_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.use
    ADD CONSTRAINT use_equip_name_fkey FOREIGN KEY (use_equip_name) REFERENCES public.equipment(equip_name) ON DELETE CASCADE;


--
-- Name: use use_exer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.use
    ADD CONSTRAINT use_exer_id_fkey FOREIGN KEY (use_exer_id) REFERENCES public.exercise(exercise_id) ON DELETE CASCADE;


--
-- Name: diet username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.diet
    ADD CONSTRAINT username_fkey FOREIGN KEY (diet_username) REFERENCES public.personnel(username) ON DELETE CASCADE;


--
-- Name: workout workout_rou_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT workout_rou_id_fkey FOREIGN KEY (workout_rou_id) REFERENCES public.rou(rou_id) ON DELETE CASCADE;


--
-- Name: workout workout_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT workout_username_fkey FOREIGN KEY (workout_username) REFERENCES public.personnel(username) ON DELETE CASCADE;


--
-- Name: workout_muscle workout_wid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workout_muscle
    ADD CONSTRAINT workout_wid_fkey FOREIGN KEY (workout_wid) REFERENCES public.workout(workout_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

